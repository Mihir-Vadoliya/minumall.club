<?php

interface com_wiris_plugin_provider_PhpAccessProvider extends com_wiris_plugin_api_AccessProvider{
	function setInitObject();
}
